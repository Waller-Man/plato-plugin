import { z } from 'zod';
export declare class RunError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
export declare function ensure(value: unknown, code: string, message: string): asserts value;
export declare function failure(error: unknown): {
    code: string;
    message: string;
};
export declare const status: z.ZodEnum<{
    queued: "queued";
    running: "running";
    cancelling: "cancelling";
    completed: "completed";
    failed: "failed";
    cancelled: "cancelled";
    interrupted: "interrupted";
}>;
export declare const model: z.ZodObject<{
    provider: z.ZodString;
    model: z.ZodString;
    reasoningEffort: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare const progress: z.ZodObject<{
    stage: z.ZodString;
    stageName: z.ZodString;
    progress: z.ZodOptional<z.ZodNumber>;
    message: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare const issue: z.ZodObject<{
    level: z.ZodEnum<{
        error: "error";
        warning: "warning";
    }>;
    stage: z.ZodOptional<z.ZodString>;
    code: z.ZodOptional<z.ZodString>;
    message: z.ZodString;
    fatal: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strict>;
export declare const artifact: z.ZodObject<{
    kind: z.ZodEnum<{
        intermediate: "intermediate";
        final: "final";
    }>;
    name: z.ZodString;
    relativePath: z.ZodString;
    mime: z.ZodString;
}, z.core.$strict>;
export declare const businessResult: z.ZodObject<{
    text: z.ZodOptional<z.ZodString>;
    files: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strict>;
export declare const requests: {
    contract: z.ZodObject<{
        toolId: z.ZodString;
    }, z.core.$strict>;
    run: z.ZodObject<{
        toolId: z.ZodString;
        input: z.ZodRecord<z.ZodString, z.ZodJSONSchema>;
        model: z.ZodOptional<z.ZodObject<{
            provider: z.ZodString;
            model: z.ZodString;
            reasoningEffort: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        timeoutMs: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>;
    id: z.ZodObject<{
        runId: z.ZodString;
    }, z.core.$strict>;
    list: z.ZodObject<{
        toolId: z.ZodOptional<z.ZodString>;
        status: z.ZodOptional<z.ZodEnum<{
            queued: "queued";
            running: "running";
            cancelling: "cancelling";
            completed: "completed";
            failed: "failed";
            cancelled: "cancelled";
            interrupted: "interrupted";
        }>>;
        limit: z.ZodOptional<z.ZodNumber>;
        offset: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>;
    wait: z.ZodObject<{
        runId: z.ZodString;
        afterSeq: z.ZodOptional<z.ZodNumber>;
        waitMs: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>;
    watch: z.ZodObject<{
        runId: z.ZodString;
        afterSeq: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>;
    artifact: z.ZodObject<{
        runId: z.ZodString;
        artifactId: z.ZodString;
    }, z.core.$strict>;
};
export declare const modelRequest: z.ZodObject<{
    messages: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        role: z.ZodLiteral<"system">;
        content: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        role: z.ZodLiteral<"assistant">;
        content: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        role: z.ZodLiteral<"user">;
        content: z.ZodUnion<readonly [z.ZodString, z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            type: z.ZodLiteral<"text">;
            text: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            type: z.ZodLiteral<"image_url">;
            image_url: z.ZodObject<{
                url: z.ZodString;
            }, z.core.$strict>;
        }, z.core.$strict>], "type">>]>;
    }, z.core.$strict>], "role">>;
}, z.core.$strict>;
