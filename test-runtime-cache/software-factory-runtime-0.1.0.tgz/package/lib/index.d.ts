import { Context, Service } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { ToolDefinition, ToolRunContext } from '@deepseek-ai/dsh-tools';
import type { Artifact, ArtifactRequest, CancelResult, ListRunsRequest, RunAccepted, RunEvent, RunIdRequest, RunList, RunRecord, RunRequest, RunUpdate, RuntimeResult, ToolContract, ToolContractRequest, WaitRunRequest, WatchRunRequest } from './contracts/runtime.js';
import type { ExecutionContext } from './sdk/index.js';
import { type RuntimeConfig } from './backend.js';
import type { RuntimeSession } from './scope.js';
export type { RuntimeSession, RuntimeSessionId } from './scope.js';
export type * from './contracts/runtime.js';
export type { RuntimeConfig } from './backend.js';
/** Backend only: service, seven model Tools, eight Remote methods and authenticated download. */
export declare class RuntimeApi extends TypertRemoteService {
    private config;
    static inject: string[];
    static Config: z<RuntimeConfig>;
    private owner;
    constructor(ctx: Context, config: RuntimeConfig);
    private backend;
    protected [Service.init](): AsyncGenerator<() => Promise<void>>;
    registerEntry(tool: ToolDefinition): () => void;
    executionFor(exec: ToolRunContext, tool: ToolDefinition): ExecutionContext;
    private invoke;
    getToolContract(runtimeSession: RuntimeSession, request: ToolContractRequest, signal?: AbortSignal): Promise<RuntimeResult<ToolContract>>;
    runTool(runtimeSession: RuntimeSession, request: RunRequest, signal?: AbortSignal): Promise<RuntimeResult<RunAccepted>>;
    getRun(runtimeSession: RuntimeSession, request: RunIdRequest, signal?: AbortSignal): Promise<RuntimeResult<RunRecord>>;
    listRuns(runtimeSession: RuntimeSession, request: ListRunsRequest, signal?: AbortSignal): Promise<RuntimeResult<RunList>>;
    waitRun(runtimeSession: RuntimeSession, request: WaitRunRequest, signal?: AbortSignal): Promise<RuntimeResult<RunUpdate>>;
    cancelRun(runtimeSession: RuntimeSession, request: RunIdRequest, signal?: AbortSignal): Promise<RuntimeResult<CancelResult>>;
    getArtifact(runtimeSession: RuntimeSession, request: ArtifactRequest, signal?: AbortSignal): Promise<RuntimeResult<Artifact>>;
    watchRun(runtimeSession: RuntimeSession, request: WatchRunRequest, signal?: AbortSignal): AsyncIterable<RuntimeResult<RunEvent>>;
}
export default RuntimeApi;
