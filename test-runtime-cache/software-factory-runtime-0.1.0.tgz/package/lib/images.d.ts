import type { Context } from '@deepseek-ai/cordis';
import type { ContentBlock } from '@deepseek-ai/dsh-llm';
import type { ModelUserContent } from './contracts/runtime.js';
export declare function userContent(ctx: Context, content: ModelUserContent, signal: AbortSignal): Promise<ContentBlock[]>;
