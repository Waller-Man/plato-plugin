import type { Context } from '@deepseek-ai/cordis';
import { type ToolDefinition, type ToolRunContext } from '@deepseek-ai/dsh-tools';
import type { Artifact, ArtifactInput, BusinessResult, ModelRef, ModelRequest, ModelResponse, ProgressReport, IssueReport, ReportStatus, RunObject } from '../contracts/runtime.js';
export type * from '../contracts/runtime.js';
export interface ExecutionContext {
    readonly runId: string;
    readonly outputDirectory: string;
    readonly signal: AbortSignal;
    reportStatus(status: ReportStatus, message?: string): Promise<void>;
    reportProgress(report: ProgressReport): Promise<void>;
    log(message: string, stage?: string): Promise<void>;
    reportIssue(issue: IssueReport): Promise<void>;
    addArtifact(file: ArtifactInput): Promise<Artifact>;
    registerCleanup(callback: () => void | Promise<void>): void;
    readonly model: {
        readonly selection?: ModelRef;
        /** Stateless API-style request: user content may mix text and image_url parts. */
        call(request: ModelRequest): Promise<ModelResponse>;
    };
}
export interface RunToolDefinition<I = RunObject> {
    toolId: string;
    description: string;
    inputSchema: RunObject;
    execute(input: Readonly<I>, execution: ExecutionContext): Promise<BusinessResult>;
}
/** Host-only protocol seam. Access requires a real Tool execution minted by DSH. */
export interface RunProtocolHost {
    registerEntry(tool: ToolDefinition): () => void;
    executionFor(exec: ToolRunContext, tool: ToolDefinition): ExecutionContext;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        sfRuntime: RunProtocolHost;
    }
}
/** Register once on plugin enable. DSH still owns policy, guards and dispatch. */
export declare function registerRunTool<I = RunObject>(ctx: Context, definition: RunToolDefinition<I>): () => Promise<void>;
